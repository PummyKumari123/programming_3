/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,a[5],sum=0,product=1;
    
    printf("enter 5 elements;");

for(i=0;i<5;++i)

    scanf("%d",&a[i]);
for(i=0;i<5;++i){

    sum=sum+a[i];
    product=product*a[i];}
    printf("the sum is %d\n",sum);
printf("the product is %d\n",product);
    return 0;
}



