/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a[10],i;
    printf("before splitting\n");
    printf("enter 10 elements:");
for(i=0;i<10;i++){
    scanf("%d",&a[i]);}
    printf("after splitting\n");
    for(i=0;i<5;i++){
        printf("%d",a[i]);}
        printf("\n");
        for(i=5;i<10;i++){
            printf("%d",a[i]);}
    return 0;
}
