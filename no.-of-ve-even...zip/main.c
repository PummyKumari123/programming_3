/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,a[20],pos_count=0,neg_count=0,even_count=0,odd_count=0,zero_count=0;
    printf("enter 20 elements");
for(i=0;i<20;i++){
    scanf("%d",&a[i]);}
    for(i=0;i<20;i++){
        if(a[i]>=0)
        pos_count++;
        else
        neg_count++;
        if(a[i]%2==0)
        even_count++;
        else
        odd_count++;
        if(a[i]==0)
        zero_count++;
        
    }
        printf("pos count is %d\n is",pos_count);
        printf("neg count is %d\n",neg_count);
        
        printf("even count is %d\n is",even_count);
        printf("odd count is %d\n",odd_count);
    
        printf("zero count is %d\n",zero_count);
    
    return 0;
}




