/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,a[5],arr[5],c;
    
    for(i=0;i<5;i++){ 
      printf("the value of a[%d]\n",i);
        scanf("%d",&a[i]);}
        for(i=0;i<5;i++){
        printf("the value of arr[%d]\n",i);
            scanf("%d",&arr[i]); }
            for(i=0;i<5;i++){
            c=a[i]-arr[i];
            printf("max.difference is %d\n",c);
}


    return 0;
}



