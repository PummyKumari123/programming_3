/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,a[5],n;
    printf("enter 5 nos.");
for(i=0;i<5;i++)

    scanf("%d",&a[i]);
    scanf("%d",&n);
    if(n==a[i])
    { printf("%d present in array",n);
    }
    else {
        printf("%d is not present in array",n); }

    return 0;
}

