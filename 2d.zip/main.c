/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i,j,a[2][3];
    for(i=0;i<2;i++){
        for(j=0;j<3;j++){
            printf("the value of a[%d][%d]\t",i,j);
            scanf("%d",&a[i][j]);
        }
    }
    printf("the value of 2d is\n");
        for(i=0;i<2;i++){
            for(j=0;j<3;j++){
                
            printf("%d",a[i][j]);
            if(j==2){
                printf("\n");}
            }
        }
    

    return 0;
}
